--残霞之辉
local m=33330724
local cm=_G["c"..m]
function cm.initial_effect(c)
	c:EnableReviveLimit()
	--link summon
	aux.AddLinkProcedure(c,aux.FilterBoolFunction(Card.IsLinkSetCard,0x555),1,1)  
	--atk
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_UPDATE_ATTACK)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e2:SetTarget(cm.indtg)
	e2:SetValue(200)
	c:RegisterEffect(e2)
end
function cm.indtg(e,c)
	return e:GetHandler():GetLinkedGroup():IsContains(c)
end