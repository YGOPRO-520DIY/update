--クラブ・タートル
function c91782219.initial_effect(c)
	c:EnableReviveLimit()
end
