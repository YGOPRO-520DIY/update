function c82221106.initial_effect(c)  
	--special summon  
	local e1=Effect.CreateEffect(c)  
	e1:SetDescription(aux.Stringid(82221106,0))  
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)  
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)  
	e1:SetRange(LOCATION_HAND)  
	e1:SetProperty(EFFECT_FLAG_DELAY)
	e1:SetCode(EVENT_SUMMON_SUCCESS)  
	e1:SetCondition(c82221106.spcon)  
	e1:SetCountLimit(1,82221106)  
	e1:SetTarget(c82221106.sptg)  
	e1:SetOperation(c82221106.spop)  
	c:RegisterEffect(e1)  
	local e2=e1:Clone()
	e2:SetCode(EVENT_SPSUMMON_SUCCESS) 
	c:RegisterEffect(e2) 
	--search
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(82221106,1))
	e3:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH) 
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_SUMMON_SUCCESS)
	e3:SetProperty(EFFECT_FLAG_DELAY)
	e3:SetCountLimit(1,82231106)
	e3:SetTarget(c82221106.pltg)
	e3:SetCost(c82221106.plcost)
	e3:SetOperation(c82221106.plop)
	c:RegisterEffect(e3)
	local e4=e3:Clone()
	e4:SetCode(EVENT_SPSUMMON_SUCCESS)
	c:RegisterEffect(e4)
	--
	local e5=Effect.CreateEffect(c)  
	e5:SetDescription(aux.Stringid(82221106,2))  
	e5:SetCategory(CATEGORY_ATKCHANGE)  
	e5:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP)  
	e5:SetType(EFFECT_TYPE_QUICK_O)  
	e5:SetRange(LOCATION_SZONE)  
	e5:SetCountLimit(1,82241106)
	e5:SetCode(EVENT_FREE_CHAIN)  
	e5:SetHintTiming(TIMING_DAMAGE_STEP+TIMING_END_PHASE)   
	e5:SetTarget(c82221106.dstg)
	e5:SetCondition(c82221106.dscon)
	e5:SetOperation(c82221106.dsop)  
	c:RegisterEffect(e5)  
end 
 
function c82221106.spfilter(c,sp)  
	return c:GetSummonPlayer()==sp and c:GetAttack()>=1500 and c:IsFaceup()
end  
function c82221106.spcon(e,tp,eg,ep,ev,re,r,rp)  
	return eg:IsExists(c82221106.spfilter,1,nil,1-tp)  
end  
function c82221106.sptg(e,tp,eg,ep,ev,re,r,rp,chk)  
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0  
		and e:GetHandler():IsCanBeSpecialSummoned(e,0,tp,false,false) end  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,e:GetHandler(),1,0,0)  
end  
function c82221106.spop(e,tp,eg,ep,ev,re,r,rp)  
	local c=e:GetHandler()  
	if not c:IsRelateToEffect(e) then return end  
	Duel.SpecialSummon(c,0,tp,tp,false,false,POS_FACEUP)  
end  
function c82221106.plcost(e,tp,eg,ep,ev,re,r,rp,chk)  
	if chk==0 then return Duel.IsExistingMatchingCard(Card.IsDiscardable,tp,LOCATION_HAND,0,1,nil) end  
	Duel.DiscardHand(tp,Card.IsDiscardable,1,1,REASON_COST+REASON_DISCARD)  
end  
function c82221106.plfilter(c)  
	return c:IsSetCard(0x293) and c:IsType(TYPE_MONSTER) and c:IsAbleToHand()  
end  
function c82221106.pltg(e,tp,eg,ep,ev,re,r,rp,chk)  
	if chk==0 then return Duel.IsExistingMatchingCard(c82221106.plfilter,tp,LOCATION_DECK,0,1,nil) end  
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK)  
end  
function c82221106.plop(e,tp,eg,ep,ev,re,r,rp)  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)  
	local g=Duel.SelectMatchingCard(tp,c82221106.plfilter,tp,LOCATION_DECK,0,1,1,nil)  
	if g:GetCount()>0 then  
		Duel.SendtoHand(g,nil,REASON_EFFECT)  
		Duel.ConfirmCards(1-tp,g)  
	end  
end  
function c82221106.filter(c)  
	return c:IsSetCard(0x293) and c:IsFaceup()
end  
function c82221106.dscon(e,tp,eg,ep,ev,re,r,rp)  
	return e:GetHandler():IsType(TYPE_TRAP) and e:GetHandler():IsType(TYPE_CONTINUOUS) and (Duel.GetCurrentPhase()~=PHASE_DAMAGE or not Duel.IsDamageCalculated())
end  
function c82221106.dstg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)  
	if chkc then return chkc:IsOnField() and c82221106.filter(chkc) end  
	if chk==0 then return Duel.IsExistingTarget(c82221106.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)  
	local g=Duel.SelectTarget(tp,c82221106.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)   
end  
function c82221106.dsop(e,tp,eg,ep,ev,re,r,rp) 
	local c=e:GetHandler()
	if not c:IsRelateToEffect(e) then return end  
	local tc=Duel.GetFirstTarget()  
	if tc:IsRelateToEffect(e) and tc:IsFaceup() then  
		local e1=Effect.CreateEffect(c)  
		e1:SetType(EFFECT_TYPE_SINGLE)  
		e1:SetCode(EFFECT_UPDATE_ATTACK)  
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)  
		e1:SetReset(RESET_EVENT+0x1fe0000)  
		e1:SetValue(500)  
		tc:RegisterEffect(e1)  
	end  
end  