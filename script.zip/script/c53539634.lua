--クリッチー
function c53539634.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,78010363,26202165,true,true)
end
