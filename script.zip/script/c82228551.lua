function c82228551.initial_effect(c)
	--cannot remove  
	local e1=Effect.CreateEffect(c)  
	e1:SetType(EFFECT_TYPE_FIELD)  
	e1:SetCode(EFFECT_CANNOT_REMOVE)  
	e1:SetRange(LOCATION_SZONE)  
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET) 
	e1:SetCondition(c82228551.con) 
	e1:SetTargetRange(1,1) 
	e1:SetTarget(aux.TargetBoolFunction(c82228551.targ))
	c:RegisterEffect(e1)  
	--Destroy
	local e2=Effect.CreateEffect(c)  
	e2:SetDescription(aux.Stringid(82228551,1))  
	e2:SetCategory(CATEGORY_DESTROY)  
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)  
	e2:SetProperty(EFFECT_FLAG_DELAY)  
	e2:SetCode(EVENT_DESTROYED)
	e2:SetCountLimit(1,82228551)  
	e2:SetCondition(c82228551.descon)  
	e2:SetTarget(c82228551.destg)  
	e2:SetOperation(c82228551.desop)  
	c:RegisterEffect(e2)
	--spsummon  
	local e3=Effect.CreateEffect(c)  
	e3:SetDescription(aux.Stringid(82228551,0))  
	e3:SetCategory(CATEGORY_SPECIAL_SUMMON)  
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)  
	e3:SetType(EFFECT_TYPE_QUICK_O)
	e3:SetCode(EVENT_FREE_CHAIN)
	e3:SetHintTiming(TIMING_END_PHASE)
	e3:SetRange(LOCATION_SZONE)  
	e3:SetCountLimit(1,82218551)
	e3:SetCondition(c82228551.con)
	e3:SetTarget(c82228551.sptg)
	e3:SetOperation(c82228551.spop)  
	c:RegisterEffect(e3)  
end
function c82228551.con(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():IsType(TYPE_TRAP) and e:GetHandler():IsType(TYPE_CONTINUOUS)
end
function c82228551.targ(c,tp)  
	return c:IsFaceup() and c:IsLocation(LOCATION_ONFIELD) and c:IsControler(tp) and c:IsSetCard(0x297)
end  
function c82228551.spfilter(c,e,tp)  
	return c:IsFaceup() and c:IsType(TYPE_TRAP) and c:IsSetCard(0x297)
	and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end  
function c82228551.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)  
	if chkc then return chkc:IsLocation(LOCATION_SZONE) and chkc:IsControler(tp) and c82228551.spfilter(chkc,e) and chkc~=e:GetHandler() end  
	if chk==0 then return Duel.IsExistingTarget(c82228551.spfilter,tp,LOCATION_SZONE,0,1,e:GetHandler(),e) and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON) 
	local g=Duel.SelectTarget(tp,c82228551.spfilter,tp,LOCATION_SZONE,0,1,1,e:GetHandler(),e)  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,1,tp,LOCATION_SZONE)  
end  
function c82228551.spop(e,tp,eg,ep,ev,re,r,rp) 
	if not e:GetHandler():IsRelateToEffect(e) then return end   
	local tc=Duel.GetFirstTarget()  
	if tc:IsRelateToEffect(e) then  
		Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)  
	end  
end  
 
function c82228551.descon(e,tp,eg,ep,ev,re,r,rp)  
	return bit.band(r,REASON_EFFECT+REASON_BATTLE)~=0  
end  
function c82228551.destg(e,tp,eg,ep,ev,re,r,rp,chk)  
	if chk==0 then return Duel.IsExistingMatchingCard(Card.IsFaceup,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,1,nil) end  
	local g=Duel.GetMatchingGroup(nil,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)  
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)  
end  
function c82228551.desop(e,tp,eg,ep,ev,re,r,rp)  
	local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)  
	if g:GetCount()>0 then  
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)  
		local sg=g:Select(tp,1,1,nil)  
		Duel.HintSelection(sg)  
		Duel.Destroy(sg,REASON_EFFECT)  
	end  
end  