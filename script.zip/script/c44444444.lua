--白狐❀幽水兰葵
function c44444444.initial_effect(c)
	c:EnableReviveLimit()
	--dam
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_AVOID_BATTLE_DAMAGE)
	e1:SetValue(1)
	c:RegisterEffect(e1)
	--n atk
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e2:SetCode(EVENT_PHASE_START+PHASE_BATTLE_START)
	e2:SetRange(LOCATION_MZONE)
	e2:SetOperation(c44444444.maop)
	c:RegisterEffect(e2)
	--atkup
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCode(EFFECT_SET_ATTACK)
	e4:SetCondition(c44444444.adcon)
	e4:SetValue(c44444444.atkval)
	c:RegisterEffect(e4)
	--Turn into Crystal
	local e15=Effect.CreateEffect(c)
	e15:SetDescription(aux.Stringid(44444444,0))
	e15:SetCode(EFFECT_SEND_REPLACE)
	e15:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e15:SetProperty(EFFECT_FLAG_SINGLE_RANGE+EFFECT_FLAG_UNCOPYABLE)
	e15:SetRange(LOCATION_MZONE)
	e15:SetCountLimit(1)
	e15:SetTarget(c44444444.crystaltg)
	c:RegisterEffect(e15)
end
function c44444444.mfilter(c)
	return c:IsFaceup() and c:IsAttackPos()
end
function c44444444.maop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetTurnPlayer()~=tp then return end
	local ct=Duel.GetMatchingGroupCount(c44444444.mfilter,tp,0,LOCATION_MZONE,nil)
	if ct~=0 then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_EXTRA_ATTACK)
		e1:SetValue(ct)
		e1:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_BATTLE)
		e:GetHandler():RegisterEffect(e1)
	end
end

function c44444444.afilter(c)
	return c:IsFaceup()
end
function c44444444.adcon(e)
	local c=e:GetHandler()
	local ph=Duel.GetCurrentPhase()
	if not (ph==PHASE_DAMAGE or ph==PHASE_DAMAGE_CAL) then return false end
	local a=Duel.GetAttacker()
	local d=Duel.GetAttackTarget()
	return Duel.IsExistingMatchingCard(c44444444.afilter,c:GetControler(),LOCATION_ONFIELD,LOCATION_ONFIELD,1,nil) 
	and ((a==e:GetHandler() and d) or d==e:GetHandler())
end
function c44444444.atkval(e,c)
	return c:GetBaseAttack()*10
end
function c44444444.repfilter(c)
	return (c:IsCode(44444005) or c:IsSetCard(0x640)) and c:IsAbleToRemoveAsCost()
end
function c44444444.crystaltg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return not c:IsReason(REASON_REPLACE)
		and Duel.IsExistingMatchingCard(c44444444.repfilter,tp,LOCATION_GRAVE,0,1,nil) end
	if Duel.SelectEffectYesNo(tp,c,96) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
		local g=Duel.SelectMatchingCard(tp,c44444444.repfilter,tp,LOCATION_GRAVE,0,1,1,nil)
		Duel.Remove(g,POS_FACEUP,REASON_COST)
		return true
	else return false end
end