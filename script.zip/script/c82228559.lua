function c82228559.initial_effect(c)  
	--link summon  
	aux.AddLinkProcedure(c,aux.FilterBoolFunction(Card.IsLinkAttribute,ATTRIBUTE_WIND),2)  
	c:EnableReviveLimit() 
	--place
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(82228559,0))
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetProperty(EFFECT_FLAG_DELAY)
	e1:SetCountLimit(1,82218559)
	e1:SetTarget(c82228559.pltg)
	e1:SetOperation(c82228559.plop)
	c:RegisterEffect(e1)
	--destroy  
	local e3=Effect.CreateEffect(c)  
	e3:SetDescription(aux.Stringid(82228559,1))  
	e3:SetCategory(CATEGORY_DESTROY+CATEGORY_SPECIAL_SUMMON)  
	e3:SetType(EFFECT_TYPE_IGNITION)  
	e3:SetRange(LOCATION_MZONE)  
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)  
	e3:SetCountLimit(1,82228559)  
	e3:SetTarget(c82228559.destg)  
	e3:SetOperation(c82228559.desop)  
	c:RegisterEffect(e3)  
end
function c82228559.plfilter(c)
	return c:IsAttribute(ATTRIBUTE_WIND) and c:IsLevel(3) and not c:IsForbidden()
end
function c82228559.pltg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c82228559.plfilter,tp,LOCATION_DECK+LOCATION_GRAVE,0,1,nil)
		and Duel.GetLocationCount(tp,LOCATION_SZONE)>0 end
end
function c82228559.plop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.GetLocationCount(tp,LOCATION_SZONE)>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOFIELD)
		local g=Duel.SelectMatchingCard(tp,c82228559.plfilter,tp,LOCATION_DECK+LOCATION_GRAVE,0,1,1,nil)
		local tc=g:GetFirst()
		if tc then
			Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true)
			local e1=Effect.CreateEffect(c)
			e1:SetCode(EFFECT_CHANGE_TYPE)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
			e1:SetReset(RESET_EVENT+RESETS_STANDARD-RESET_TURN_SET)
			e1:SetValue(TYPE_TRAP+TYPE_CONTINUOUS)
			tc:RegisterEffect(e1)
		end
	end
end
function c82228559.desfilter(c,ft)  
	return ft>0 or (c:IsLocation(LOCATION_MZONE) and c:GetSequence()<5)  
end  
function c82228559.spfilter(c,e,tp)  
	return c:IsLevelBelow(3) and c:IsAttribute(ATTRIBUTE_WIND) and c:IsCanBeSpecialSummoned(e,0,tp,false,false)  
end  
function c82228559.destg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)  
	if chkc then return false end  
	local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)  
	if chk==0 then return ft>-1  
		and Duel.IsExistingTarget(c82228559.desfilter,tp,LOCATION_ONFIELD,0,1,nil,ft)  
		and Duel.IsExistingTarget(c82228559.spfilter,tp,LOCATION_GRAVE,0,1,nil,e,tp) end  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)  
	local g1=Duel.SelectTarget(tp,c82228559.desfilter,tp,LOCATION_ONFIELD,0,1,1,nil,ft)  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)  
	local g2=Duel.SelectTarget(tp,c82228559.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,e,tp)  
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g1,1,0,0)  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g2,1,0,0)  
end  
function c82228559.desop(e,tp,eg,ep,ev,re,r,rp)  
	local ex,g1=Duel.GetOperationInfo(0,CATEGORY_DESTROY)  
	local ex,g2=Duel.GetOperationInfo(0,CATEGORY_SPECIAL_SUMMON)  
	local tc1=g1:GetFirst()  
	local tc2=g2:GetFirst()  
	if tc1:IsRelateToEffect(e) and tc2:IsRelateToEffect(e) and Duel.Destroy(tc1,REASON_EFFECT)~=0 then  
		Duel.SpecialSummon(tc2,0,tp,tp,false,false,POS_FACEUP)  
	end  
end  