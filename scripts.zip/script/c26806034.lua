--萤火之光·诗岸
function c26806034.initial_effect(c)
	--link summon
	aux.AddLinkProcedure(c,nil,3)
	c:EnableReviveLimit()	
end
