--四季诗画-冬淞
function c44460124.initial_effect(c)
	
end
