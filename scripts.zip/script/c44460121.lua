--四季诗画-春茶
function c44460121.initial_effect(c)
	
end
