--十二宫·摩羯座
function c44470460.initial_effect(c)
	
end
