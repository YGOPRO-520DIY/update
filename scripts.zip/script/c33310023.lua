--泰拉居民 向导
local m=33310023
local cm=_G["c"..m]
if cm then
   cm.setcard="terraria"
end