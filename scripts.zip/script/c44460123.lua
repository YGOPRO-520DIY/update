--四季诗画-秋枫
function c44460123.initial_effect(c)
	
end
