--四季诗画-夏荷
function c44460122.initial_effect(c)
	
end
